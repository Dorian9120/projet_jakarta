package org.efrei.start.services;

import org.efrei.start.models.Acteur;
import org.efrei.start.repositories.ActorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActorService {

    private final ActorRepository repository;

    @Autowired
    public ActorService(ActorRepository repository) {
        this.repository = repository;
    }

    public List<Acteur> findAll() {
        List<Acteur> acteurs = repository.findAll();
        System.out.println(acteurs); // Facultatif, vous pouvez le retirer en production
        return acteurs;
    }

    public void create(Acteur acteur) {
        if (acteur.getNom() == null || acteur.getPrenom() == null) {
            throw new IllegalArgumentException("Le nom et le prénom sont obligatoires");
        }
        repository.save(acteur);
    }

    public Acteur findById(String id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Acteur avec l'ID " + id + " non trouvé"));
    }

    public void deleteById(String id) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Acteur avec l'ID " + id + " non trouvé");
        }
        repository.deleteById(id);
    }

    public void update(String id, Acteur acteur) {
        Acteur updatedActeur = findById(id);
        updatedActeur.setNom(acteur.getNom());
        updatedActeur.setPrenom(acteur.getPrenom());
        repository.save(updatedActeur);
    }
}
