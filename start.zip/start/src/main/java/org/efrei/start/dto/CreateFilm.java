package org.efrei.start.dto;

import org.efrei.start.global.Categorie;
import org.efrei.start.models.Film;

public class CreateFilm {

    private String titre;
    private Categorie categorie;

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }

}

