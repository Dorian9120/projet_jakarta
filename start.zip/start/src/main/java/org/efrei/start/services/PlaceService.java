package org.efrei.start.services;

import org.efrei.start.models.Place;
import org.efrei.start.repositories.PlaceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlaceService {

    private final PlaceRepository placeRepository;

    @Autowired
    public PlaceService(PlaceRepository placeRepository) {
        this.placeRepository = placeRepository;
    }

    public List<Place> findAll() {
        return placeRepository.findAll();
    }

    public Place findById(String id) {
        return placeRepository.findById(id).orElse(null);
    }

    public void create(Place place) {
        placeRepository.save(place);
    }

    public void update(String id, Place place) {
        Place existingPlace = findById(id);
        if (existingPlace != null) {
            existingPlace.setNumero(place.getNumero());
            existingPlace.setEtat(place.getEtat());
            placeRepository.save(existingPlace);
        }
    }

    public void deleteById(String id) {
        placeRepository.deleteById(id);
    }
}
