package org.efrei.start.global;

public enum Categorie {
}
