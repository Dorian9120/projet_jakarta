package org.efrei.start.services;

import org.efrei.start.models.Seance;
import org.efrei.start.repositories.SeanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeanceService {

    private final SeanceRepository seanceRepository;

    @Autowired
    public SeanceService(SeanceRepository seanceRepository) {
        this.seanceRepository = seanceRepository;
    }

    public List<Seance> findAll() {
        return seanceRepository.findAll();
    }

    public Seance findById(String id) {
        return seanceRepository.findById(id).orElse(null);
    }

    public void create(Seance seance) {
        seanceRepository.save(seance);
    }

    public void update(String id, Seance seance) {
        Seance existingSeance = findById(id);
        if (existingSeance != null) {
            existingSeance.setDateHeure(seance.getDateHeure());
            existingSeance.setActeurs(seance.getActeurs());
            seanceRepository.save(existingSeance);
        }
    }

    public void deleteById(String id) {
        seanceRepository.deleteById(id);
    }
}
