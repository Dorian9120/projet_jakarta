package org.efrei.start.controllers;

import org.efrei.start.models.Seance;
import org.efrei.start.services.SeanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/seances")
public class SeanceController {

    private final SeanceService seanceService;

    @Autowired
    public SeanceController(SeanceService seanceService) {
        this.seanceService = seanceService;
    }

    @GetMapping
    public ResponseEntity<List<Seance>> findAll() {
        List<Seance> seances = seanceService.findAll();
        return new ResponseEntity<>(seances, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Seance> findById(@PathVariable String id) {
        Seance seance = seanceService.findById(id);
        if (seance == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(seance, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Seance seance) {
        seanceService.create(seance);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable String id, @RequestBody Seance seance) {
        Seance existingSeance = seanceService.findById(id);
        if (existingSeance == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        seanceService.update(id, seance);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable String id) {
        Seance existingSeance = seanceService.findById(id);
        if (existingSeance == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        seanceService.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
