package org.efrei.start.controllers;

import org.efrei.start.models.Place;
import org.efrei.start.services.PlaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/places")
public class PlaceController {

    private final PlaceService placeService;

    @Autowired
    public PlaceController(PlaceService placeService) {
        this.placeService = placeService;
    }

    @GetMapping
    public ResponseEntity<List<Place>> findAll() {
        List<Place> places = placeService.findAll();
        return new ResponseEntity<>(places, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Place> findById(@PathVariable String id) {
        Place place = placeService.findById(id);
        if (place == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(place, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Place place) {
        placeService.create(place);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable String id, @RequestBody Place place) {
        Place existingPlace = placeService.findById(id);
        if (existingPlace == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        placeService.update(id, place);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable String id) {
        Place existingPlace = placeService.findById(id);
        if (existingPlace == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        placeService.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
