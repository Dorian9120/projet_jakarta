package org.efrei.start.models;

import jakarta.persistence.*;

@Entity
public class Place {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne
    @JoinColumn(name = "seance_id", nullable = false)
    private Seance seance;

    @Column(name = "numero", nullable = false)
    private int numero;

    @Column(name = "etat", nullable = false)
    private String etat;  // Par exemple "Libre", "Réservée", "Occupée"

    // Constructeurs, Getters et Setters

    public Place() {
    }

    public Place(Seance seance, int numero, String etat) {
        this.seance = seance;
        this.numero = numero;
        this.etat = etat;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Seance getSeance() {
        return seance;
    }

    public void setSeance(Seance seance) {
        this.seance = seance;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }
}
